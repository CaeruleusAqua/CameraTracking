//-----------------------------------------------------------------------------
//  Basler pylon SDK
//  Copyright (C) 2006-2013 Basler
//  http://www.baslerweb.com
//-----------------------------------------------------------------------------
#pragma once
#pragma message( "The CBaslerGigETL class has been removed - see the migration guide in the pylon C++ API documentation for more information." )

