//  This file is generated automatically. Do not modify! 
#define GENICAM_VERSION_MAJOR 2 
#define GENICAM_VERSION_MINOR 3 
#define GENICAM_VERSION_SUBMINOR 1
#define GENICAM_VERSION_BUILD 0 
#if defined (__linux__)
#  if defined (__arm__)
#define GENICAM_COMPILER gcc43 
#  else
#define GENICAM_COMPILER gcc40 
#  endif /* __arm __ */
#elif defined(__APPLE__)
#define GENICAM_COMPILER gcc42 
#else
#define GENICAM_COMPILER VC80 
#endif
